# HLS Player 1.0.1 — proyecto webOS TV

Proyecto fuente independiente con interfaz deportiva oscura y selector de variantes HLS. No contiene canales, listas, URLs, claves ni extractor del IPK ESPN original.

## Funciones implementadas
- `appinfo.json` con metadatos webOS y ambos iconos requeridos para pruebas (80×80 y 130×130 PNG).
- Entrada de URL `.m3u8` autorizada.
- Reproducción con hls.js 1.5.20 cuando el navegador ofrece MSE.
- Selector de variantes reales anunciadas por el manifiesto HLS; automático o variante concreta con resolución/bitrate.
- Alternativa HLS nativa cuando el motor no ofrece MSE. En ese modo el control manual puede no estar disponible.
- Indicadores de carga, pausa, espera/búfer y errores básicos.
- Recuerda la última URL localmente.
- Scripts de empaquetado para Linux/macOS (`package.sh`) y Windows (`package.bat`).

## Límites técnicos
- Elegir 360p/480p solo funciona si el manifiesto maestro HLS ofrece esas variantes y el servidor permite descargarlas.
- El reproductor no transcodifica el vídeo ni puede inventar una variante de menor bitrate. Si solo hay una variante, no se puede forzar una resolución menor desde el cliente.
- A 1 Mbps, incluso una variante 360p puede congelarse si su bitrate más la sobrecarga supera el ancho de banda real disponible.
- hls.js se carga desde CDN fijado a la versión 1.5.20. Para evitar depender del CDN, descarga la distribución `hls.min.js` de esa versión desde el proyecto oficial y guárdala como `vendor/hls.min.js`; después cambia el `src` del script en `index.html` a `vendor/hls.min.js`. El archivo no se incluye aquí.
- El manifiesto y los segmentos deben permitir CORS desde la aplicación. DRM, tokens expirados, cabeceras propietarias o restricciones del servidor pueden impedir la reproducción.
- No se ha probado en un televisor físico ni con una URL HLS real en este entorno.

## Preparar el entorno
La documentación actual de LG recomienda el paquete `@webos-tools/cli` (no la CLI antigua `webOS TV CLI`, que está obsoleta). Requisitos publicados para la CLI: Windows 10+ 64-bit, Ubuntu 20.04+ 64-bit o macOS 10.13+ 64-bit; Node.js/npm. LG recomienda Node 14.15.1–16.20.2 en su guía de instalación.

Instala en el ordenador:

```bash
npm install -g @webos-tools/cli
ares -V
```

## Antes de empaquetar
1. Abre `appinfo.json` y cambia `com.example.hlsplayer` por un ID propio, único y en minúsculas con formato de dominio inverso. No uses un ID que pertenezca a otra app.
2. Revisa el título y vendor si quieres personalizarlos.
3. En `index.html`, deja CDN o añade localmente `vendor/hls.min.js` según la instrucción anterior.
4. Empaqueta desde la carpeta del proyecto:
   - Linux/macOS: `./package.sh`
   - Windows: `package.bat`
   - Manual: `ares-package --no-minify -o dist .`
5. El IPK aparecerá en la carpeta `build-output/` hermana del proyecto si la CLI finaliza correctamente.

## Instalar y probar
Con Developer Mode habilitado en el televisor y el dispositivo registrado en la CLI:

```bash
ares-setup-device --list
ares-install -d NOMBRE_TV ../build-output/ARCHIVO_GENERADO.ipk
ares-launch -d NOMBRE_TV com.tudominio.hlsplayer
```

Sustituye `NOMBRE_TV`, el nombre real del IPK y el ID de aplicación. Usa una URL HLS autorizada que anuncie varias variantes para comprobar el selector. Si el televisor reproduce por HLS nativo, el menú manual podría no funcionar; eso se debe verificar en el modelo/firmware concreto.

## Estado de este paquete
Código y metadatos preparados; JSON y sintaxis JavaScript verificados localmente. **No se generó el IPK** porque `ares-package`/webOS CLI no está instalado en el entorno de trabajo. Tampoco se pudo validar en el televisor.
