# Crear el IPK desde Android usando GitHub Actions

Este proyecto incluye `.github/workflows/build-ipk.yml` para compilar el IPK en los servidores de GitHub, sin instalar webOS CLI en el teléfono.

## Pasos generales
1. Crea una cuenta gratuita en GitHub si aún no tienes una.
2. Crea un repositorio nuevo y sube el contenido de esta carpeta, conservando la carpeta `.github/workflows/`.
3. En el repositorio, abre la pestaña **Actions** y selecciona **Build webOS IPK**.
4. Pulsa **Run workflow**. Espera a que el trabajo termine correctamente.
5. En la ejecución terminada, descarga el artefacto **HLS-Player-IPK**. Dentro estará el archivo `.ipk`.
6. Instala ese IPK en el televisor con webOS Dev Manager.

## Importante
- El repositorio debe contener `appinfo.json` en su raíz, además de `index.html`, `js/`, `css/`, `icon.png`, `largeIcon.png` y `.github/workflows/build-ipk.yml`.
- Cambia primero el ID `com.example.hlsplayer` de `appinfo.json` por uno único tuyo.
- El workflow usa Ubuntu y la CLI oficial actual `@webos-tools/cli` para ejecutar `ares-package`.
- La compilación puede fallar si la CLI oficial cambia o si el proyecto tiene algún error de empaquetado; el resultado de Actions mostrará el motivo.
- Compilar no garantiza que la reproducción funcione en el televisor: aún hay que probarlo con una URL HLS autorizada y compatible.
